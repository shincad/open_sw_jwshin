/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : getpio.c                       */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                    From GetPIOBuff[] to FIFO                */
/*=============================================================*/

char GetPIOBuff(Ch)     /* Parallel(FIFO) Routine */
unsigned char *Ch;
{
	unsigned char EmptyFlag;
   	unsigned char ExOrVal;
   	EmptyFlag = (M_6821CS & 0x01); /* Flag Check */
   	if(EmptyFlag == 0) {
    	return -1;
   	}
   	*Ch = 0xFF ^ P_RD_FIFO;        /* Signal Reverse */
   	return 0;
}
