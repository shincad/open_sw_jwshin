/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : vtdbtb.c                       */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                    VTDoubleTB Routine                       */
/*=============================================================*/
VTDoubleTB(FontAdr,ChInfo)   /* Vertical Extension */
char *FontAdr;
struct CH_IMG *ChInfo;
{
	int i,x=0;
    for(i=0; i<(ChInfo->Body);i++){
    	ChInfo->Buff[x]     = VTFontTB[(*FontAdr)&0x0F];
        ChInfo->Buff[x+1]   = VTFontTB[((*FontAdr)&0xF0)>>4];
        ChInfo->Buff[x+2]   = VTFontTB[(*(FontAdr+1))&0x0F];
        ChInfo->Buff[x+144] = VTFontTB[((*(FontAdr+1))&0xF0)>>4];
        ChInfo->Buff[x+145] = VTFontTB[(*(FontAdr+2))&0x0F];
        ChInfo->Buff[x+146] = VTFontTB[((*(FontAdr+2))&0xF0)>>4];
        FontAdr += 3;
        x += 3;
    }
}
