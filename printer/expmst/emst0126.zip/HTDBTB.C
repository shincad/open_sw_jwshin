/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : htdbtb.c                       */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                     HTDoubleTB Routine                      */
/*=============================================================*/
HTDoubleTB(FontAdr,ChInfo)   /* Horizontal Extenstion */
char *FontAdr;
struct CH_IMG *ChInfo;
{
	int i,x=0;
    for(i=0; i<ChInfo->Body; i++){
    	ChInfo->Buff[x]   = ChInfo->Buff[x+3] = *FontAdr;
        ChInfo->Buff[x+1] = ChInfo->Buff[x+4] = *(FontAdr+1);
        ChInfo->Buff[x+2] = ChInfo->Buff[x+5] = *(FontAdr+2);
        FontAdr += 3;
        x += 6;
    }
    ChInfo->Col  *= 2;
    ChInfo->Body *= 2;
}
