/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : chkpio.c                       */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                   CheckPIOBuff Routine                      */
/*=============================================================*/
CheckPIOBuff()
{
	unsigned char EmptyFlag;
   	EmptyFlag = (M_6821CS & 0x01);   /* FIFO Flag Check */
   	if(EmptyFlag == 0) {
   		return EMPTY;
   	}
   	else {
      	return NOTEMPTY;
   	}
}
