/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : sendslv.c                      */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                     SendSlave Routine                       */
/*=============================================================*/
SendSlave(Value)
unsigned char Value;
{
	union REG_UNION Reg0;
    SendFIFO(STX);              /* Start Code to Slave */
    SendFIFO(0);                /* Normal Code to Slave */
    switch(Value) {
    	case LPI_CMD :  SendFIFO(LPI_CMD);      /* Change LPI */
                        Reg0.Two = LFInfo.DotLenOfLine;
                        SendFIFO(Reg0.Order.Hi);   /* High 1 Byte */
                        SendFIFO(Reg0.Order.Low);  /* Low  1 Byte */
                        break;
        case PL_CMD  :  SendFIFO(PL_CMD);       /* Change Paper Length */
                        Reg0.Two = PageLen;
                        SendFIFO(Reg0.Order.Hi);
                        SendFIFO(Reg0.Order.Low);
                        break;
        case LF_CMD  :  SendFIFO(LF_CMD);       /* Line Feed */
                        Reg0.Two = (LFInfo.DotLenOfLine * LFInfo.Sum +
                        AdjLPIErr(LFInfo.Sum));
                        SendFIFO(Reg0.Order.Hi);
                        SendFIFO(Reg0.Order.Low);
                        break;
        case FF_CMD  :  SendFIFO(FF_CMD);       /* Form Feed */
                        SendFIFO(0);
                        SendFIFO(1);
                        break;
        case DATA_FF_CMD : SendFIFO(DATA_FF_CMD);
                           SendFIFO(0);
                           SendFIFO(1);
                           break;
    }
}
