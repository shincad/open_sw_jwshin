#include <stdio.h>


#define CPI			0
#define PROPORTION 	1
#define CONDEN		2
#define EMPHA		3
#define DBPRINT		4
#define HTDOUBLE	5
#define ITALIC		6
#define UNDERLINE	7

#define SET			1
#define RESET		0





/*---------------------------------------------  Main Function -*/

void main(void)
{
	unsigned int BitValue1,TempValue,BitCnt,i;
	unsigned char BitValue[8];
	unsigned int ActValue;
			printf("Input Value :");
			scanf("%d",&ActValue);
			BitCnt = 0;
			BitValue1 = 0;
			TempValue = ActValue;
			while(BitCnt < 8) {
					  BitValue1        = TempValue % 2;
					  TempValue        = TempValue / 2;
					  BitValue[BitCnt] = BitValue1;
					  printf("BitValue[%d] = %d, %d \n",BitCnt,BitValue1,BitValue[BitCnt]);
					  BitCnt++;
			}

			for(i=0;i<BitCnt;i++) {

				switch(i) {
						  case CPI        : if(BitValue[CPI] == SET) {
												printf("12CPI\n");
											}
											else {
												printf("10CPI\n");
											}
											break;
						  case PROPORTION : if(BitValue[PROPORTION] == SET) {
												printf("Proportion Setting\n");
											}
											else {
												printf("Proportion Reset\n");
											}
											break;
						  case CONDEN	  : if(BitValue[CONDEN] == SET) {
												printf("Character Condensing\n");
											}
											else {
												printf("Condensing Reset\n");
											}
											break;
						  case EMPHA	  : if(BitValue[EMPHA] == SET) {
												printf("Emphasizing\n");
											}
											else {
												printf("Emphasizing Reset\n");
											}
											break;
						  case DBPRINT    : if(BitValue[DBPRINT] == SET) {
												printf("Double Printing\n");
											}
											else {
												printf("Double Printing Reset\n");
											}
											break;
						  case HTDOUBLE	  : if(BitValue[HTDOUBLE] == SET) {
												printf("Horizontal Double\n");
											}
											else {
												printf("Horizontal Double Reset\n");
											}
											break;
						  case ITALIC	  : if(BitValue[ITALIC] == SET) {
												printf("Italic Character\n");
											}
											else {
												printf("Italic Character Reset\n");
											}
											break;
						  case UNDERLINE  : if(BitValue[UNDERLINE] == SET) {
												printf("UnderLine Setting\n");
											}
											else {
												printf("UnderLine Reset\n");
											}
											break;
						  default 		  : break;
				}
			}
}
