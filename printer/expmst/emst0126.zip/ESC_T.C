#include <stdio.h>

int ActValue = 0;
int TempValue = 0;

void main()
{

							printf("Input Value\n");
                            scanf("%d",&ActValue);
	       					ActValue = ActValue - 30;
                            ActValue = ActValue << 2;
							scanf("%d",&TempValue);
                            TempValue = TempValue - 30;
                            TempValue = TempValue << 1;
                            TempValue = TempValue | ActValue;
                            scanf("%d",&ActValue);
                            ActValue = ActValue - 30;
                            TempValue = TempValue | ActValue;
                            printf("%d",TempValue);
}

