/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : m_init.c                       */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                Master Initialization Routine                */
/*=============================================================*/
Initialize()
{
	SIOInit();
    while(StartEvent != SET);
}
