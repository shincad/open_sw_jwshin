#include <stdio.h>


struct CH_IMG {
        unsigned char Col;
        unsigned char Body;
        unsigned char Rear;
        unsigned char Buff[100];
} ChImg;



main() 
{
           unsigned int Len;
           Len = 36;

           asm(" XREF _ChImg ");
           asm(" MOVE.B 'Len',D1 ");
           asm(" CLR.B D2 ");
           asm(" LOOP: ");
           asm(" MOVEA.L #_ChImg+3,A1 ");
           asm(" CLR.B (A1)+ ");
           asm(" SUBQ.B #1,D1 ");
           asm(" CMP.B D1,D2 ");
           asm(" BNE.S LOOP ");              

}    
