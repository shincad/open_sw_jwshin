/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : rvmem.c                        */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                    ReverseMem Routine                       */
/*=============================================================*/
ReverseMem(ChImg)        /* Reverse Character */
struct CH_IMG *ChImg;
{
	int i,Len;
    Len = ChImg->Col * 3;
    if(FontInfo.VTDouble == SET) {
    	if(FontInfo.HTDouble == SET) {
        	for(i=0;i<Len;i++) {
            	ChImg->Buff[i]     ^= 0xFF;
                ChImg->Buff[216+i] ^= 0xFF;
            }
        }
        else {
        	for(i=0;i<Len;i++) {
        		ChImg->Buff[i]     ^= 0xFF;
            	ChImg->Buff[144+i] ^= 0xFF;
        	}
        }
    }
    else {
    	for(i=0;i<Len;i++) {
        	ChImg->Buff[i] ^= 0xFF;
        }
    }
}
