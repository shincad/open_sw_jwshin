/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : adj_err.c                      */
/*                  Program Date : 1997. 2.                    */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                    AdjLPIErr Routine                        */
/*=============================================================*/

AdjLPIErr(Length)
unsigned char Length;
{
	unsigned int AdjVal;
   	if(LFInfo.AdjMod != 0) {
		AdjVal = LFInfo.AdjMod * Length + LFInfo.AdjRemain;
     	LFInfo.AdjRemain = AdjVal % 100;
    	return(AdjVal / 100);
    } /* if */
   	else {
   		return 0;
   	} /* else */
}
