/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : copyimg.c                      */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                   CopyToStImg Routine                       */
/*=============================================================*/
/*     From Character Image Buffer to String Image Buffer      */

CopyToStImg(DestBase,SourBase,Col)
unsigned int DestBase;
unsigned int SourBase;
unsigned int Col;
{
	unsigned int Len;
    Len = SourBase + (Col*3);
    DestBase = DestBase + (StImg.Pos*3);
    memcpy( &(StImg.Buff[DestBase]), &(ChImg.Buff[SourBase]),Len-SourBase);
    memset( &(ChImg.Buff[SourBase]), 0 , Len-SourBase);
    StImg.Pos += ChImg.Col;
}
