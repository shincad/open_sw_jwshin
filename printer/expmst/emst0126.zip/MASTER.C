/*=============================================================*/
/*                  KD20B Master Program                       */
/*                  date :  1997 / 2 / 4                       */
/*=============================================================*/

#include <stdio.h>
#include "m_define.h"
#include "m_var.mem"
u_char Test(void);

/*=============================================================*/
/*                  Function Declaration                       */
/*=============================================================*/

extern void interrupt Serial(void);
extern void interrupt S_M_Int(void);
char GetSIOBuff(u_char *);
char SendBuff(u_char,u_int,u_int *);
u_char GetHostBuff(void);
u_char HexTest(void);

/*=============================================================*/
/*                  Serial Interrupt Routine                   */
/*=============================================================*/

void interrupt Serial(void)
{
    INT_DIS;
    while((ACIASR & 0x01) != 1);      /* Received data register full */
    HostBuff[HWp++] = ACIADR;         /* From Data Register to Buffer */
    if(HWp > MAX_HBUFF) {
                HWp = 0;
    }
    Gap = HWp - HRp;
    if(Gap >= 0) {
                if((Gap > P_DEAD) && (HProtect == RESET)) {
                            HProtect = SET;
                            if(Protocol == DTR_MODE) {
                                       ACIACR = 0xD5;
                            }
                            else {
                                       while((ACIASR & 0x02) != 0);
                                       ACIADR = XOFF;
                            }
                }
    }
    else {
                if((Gap > -N_DEAD) && (HProtect == RESET)) {
                            HProtect = SET;
                            if(Protocol == DTR_MODE) {
                                       ACIACR = 0xD5;
                            }
                            else {
                                       while((ACIASR & 0x02) != 0);
                                       ACIADR = XOFF;
                            }
                }
    }
    INT_ENB;
}

void interrupt Parallel(void)
{
}

/*=============================================================*/
/*                    S_M_Interrupt Routine                    */
/*=============================================================*/

u_char Step;

void interrupt S_M_Int(void)
{
    u_char Data;
    u_char Cmd;
    INT_DIS;
    Data = S_M_READ;
    if(Data == STX) {
            Step = 1;
            INT_ENB;
            return;
    }
    else
    if(Data == ETX) {
            switch(Cmd) {
                        case SET_ITEM        : ItemEvent = SET;
                                               break;
                        case SELF_TEST_START : SelfTestEvent = SELF_TEST_START;
                                               break;
                        case SELF_TEST_STOP  : SelfTestEvent = SELF_TEST_STOP;
                                               break;
                        case CONFIG          : ConfigEvent   = SET;
                                               break;
                        case START           : StartEvent    = SET;
                                               break;
                        default              : break;
            }
            Step = 0;
    }
    switch(Step) {
            case 1 : Cmd   = Data - CMD_WEIGHT;
                     Step  = 2;
                     CmdCt = 0;
                     break;
            case 2 : CmdBuf[CmdCt] = Data - CMD_WEIGHT;
                     CmdCt++;
                     ItemEvent = RESET;
                     break;
    }
    INT_ENB;
}

/*=============================================================*/
/*                    Serial Initialization                    */
/*=============================================================*/

SIOInit()
{
    INT_DIS;
    HRp = 0;
    HWp = 0;
    HProtect = RESET;           /* XON/XOFF */
    ACIACR   = 0x03;   /* Control Register CR1,CR0=1,1 : Mst Reset */
    ACIACR   = 0xD5;   /* Parity Bit=None,Data Bit=8,Stop Bit=1,RTS = L */
                       /* DTR = H */
                       /* Tx interrupt Disable, Rx interrupt Enable */
    INT_ENB;
}

/*=============================================================*/
/*                    From HostBuff[] to FIFO                  */
/*=============================================================*/

char GetSIOBuff(Ch)
u_char *Ch;
{
    if(HRp == HWp) {
                return -1;
    }
    *Ch = HostBuff[HRp++];
    if(HRp > MAX_HBUFF) {
                HRp = 0;
    }
    if(HProtect == SET) {
                Gap = HWp - HRp;
                if(Gap >= 0) {
                         if(Gap < P_LIVE) {
                                      HProtect = RESET;
                                      if(Protocol == DTR_MODE) {
                                                ACIACR = 0x95;
                                      }
                                      else {
                                                while((ACIASR & 0x02) != 0);
                                                ACIADR = XON;
                                                ACIADR = XON;
                                                ACIADR = XON;
                                      }
                         }
                }
                else {
                         if(Gap < -N_LIVE) {
                                      HProtect = RESET;
                                      if(Protocol == DTR_MODE) {
                                                ACIACR = 0x95;
                                      }
                                      else {
                                                while((ACIASR & 0x02) != 0);
                                                ACIADR = XON;
                                                ACIADR = XON;
                                                ACIADR = XON;
                                      }
                         }
                }
    }
    return 0;
}




/*=============================================================*/
/*                    GetHostBuff Routine                      */
/*=============================================================*/
u_char GetHostBuff()
{
    u_char Data;
    if(HostPortMod == SERIAL_PORT) {
                  while(GetSIOBuff(&Data) == -1);
    }
    else {
    }
    return Data;
}

/*=============================================================*/
/*                   CheckHostBuff Routine                     */
/*=============================================================*/
CheckHostBuff()
{
    if(HostPortMod == SERIAL_PORT) {
             EmptyState = CheckSIOBuff();
    }
    else {
    }
    return EmptyState;
}

/*=============================================================*/
/*                   CheckSIOBuff Routine                      */
/*=============================================================*/
CheckSIOBuff()
{
    if(HRp == HWp) {
                return EMPTY;
    }
    else {
                return NOTEMPTY;
    }
}
/*=============================================================*/
/*                     LFProc() Routine                        */
/*=============================================================*/

LFProc()
{
    TabCt = 0;
    AutoClrCtr();
    switch(BitImgMode) {
                        case NOT_BITIMG : break;
                        case BITIMG_8   : StImg.Part     = 0;
                                          StImg.Pos      = Margin.Left;
                                          StImg.HaveVT   = RESET;
                                          StImg.HaveVTUp = RESET;
                                          SendStImg(8,STIMG_NOSWAP);
                                          ClrStImg(8);
                                          BitImgMode     = NOT_BITIMG;
                                          return;
                        case BITIMG_24  : StImg.Part     = 0;
                                          StImg.Pos      = Margin.Left;
                                          StImg.HaveVT   = RESET;
                                          StImg.HaveVTUp = RESET;
                                          SendStImg(24,STIMG_NOSWAP);
                                          ClrStImg(24);
                                          BitImgMode     = NOT_BITIMG;
                                          return;
                        default:          break;
    }
    if(EmptyImgBuff == SET) {
                        LFInfo.Sum++;
                        if(LFInfo.Sum > MAX_LF_RANGE) {
                                     SendSlave(LF_CMD);
                                     LFInfo.Sum = 0;
                        }
    return;
    }
    EmptyImgBuff = SET;
    if(StImg.Part == 0) {
                        if((StImg.HaveVTUp == SET) && (StImg.HaveVT == RESET)) {
                                     StImg.Part     = 1;
                                     StImg.Pos      = Margin.Left;
                                     StImg.HaveVTUp = RESET;
                        }
                        else
                        if(StImg.HaveVT   == SET) {
                                     StImg.Pos      = Margin.Left;
                                     StImg.HaveVT   = RESET;
                                     StImg.HaveVTUp = RESET;
                                     SendStImg(DOUBLE_BUFF,STIMG_SWAP);
                                     ClrStImg(DOUBLE_BUFF);
                        }
                        else {
                                     StImg.Pos = Margin.Left;
                                     SendStImg(SINGLE_BUFF,STIMG_NOSWAP);
                                     ClrStImg(SINGLE_BUFF);
                        }
    }
    else {
                        StImg.Part     = 0;
                        StImg.Pos      = Margin.Left;
                        StImg.HaveVT   = RESET;
                        StImg.HaveVTUp = RESET;
                        SendStImg(DOUBLE_BUFF,STIMG_NOSWAP);
                        ClrStImg(DOUBLE_BUFF);
    }
}

/*=============================================================*/
/*                     SendStImg Routine                       */
/*=============================================================*/
u_int LFCt;

u_char FontLine;
u_int LFLen;

SendStImg(BuffLine,Swap)
u_char BuffLine;
u_char Swap;
{
    int Tab;
    u_int LFVal;
    if(LFInfo.Sum > 0) {
                        SendSlave(LF_CMD);
                        LFInfo.Sum = 0;
    }
    if(BuffLine == DOUBLE_BUFF) {
                        LFVal = LFInfo.DotLenOfLine * 2 + AdjLPIErr(2);
    }
    else {
                        LFVal = LFInfo.DotLenOfLine + AdjLPIErr(1);
    }
    if(BuffLine < LFVal) {
                        FontLine = BuffLine;
                        LFLen    = LFVal - BuffLine + 1;
    }
    else {
                        FontLine = LFVal;
                        LFLen    = 1;
    }

    LFCt = 0;
    if(Swap == SET) {
                        for(Tab=3;Tab<6;Tab++) {
                                RolProc(Tab);
                                if(SendBuff(FontLine,LFLen,&LFCt) == -1) {
                                   return;
                                }
                        }
                        for(Tab=0;Tab<3;Tab++) {
                                RolProc(Tab);
                                if(SendBuff(FontLine,LFLen,&LFCt) == -1) {
                                   return;
                                }
                        }
    }
    else {
                        if(BitImgMode == NOT_BITIMG) {
                                for(Tab=0;Tab<6;Tab++) {
                                        RolProc(Tab);
                                        if(SendBuff(FontLine,LFLen,&LFCt) == -1) {
                                                return;
                                        }
                                } /* for */
                        }
                        else {
                                for(Tab=0;Tab<6;Tab++) {
                                        ImageRolProc(Tab);
                                        if(SendBuff(FontLine,LFLen,&LFCt) == -1) {
                                                return;
                                        }
                                } /* for */
                        }
    }
}

/*=============================================================*/
/*                    AdjLPIErr Routine                        */
/*=============================================================*/

AdjLPIErr(Length)
u_char Length;
{
    u_int AdjVal;
    if(LFInfo.AdjMod != 0) {
                    AdjVal = LFInfo.AdjMod * Length + LFInfo.AdjRemain;
                    LFInfo.AdjRemain = AdjVal % 100;
                    return(AdjVal / 100);
    }
    else {
                    return 0;
    }
}

/*=============================================================*/
/*                      RolProc Routine                        */
/*=============================================================*/

RolProc(Tab)
int Tab;
{
    int i;
    int Pos;
    int Dot;
    int BuffPos=0,Bpos=0;
        Tab = (Tab>2)?(Tab-3)+7344:Tab;
        for(i = 0;i < 7344 ;i=i+24) {
                Pos   = i + Tab;
                DSLB0 = StImg.Buff[Pos];
                DSLB1 = StImg.Buff[Pos+3];
                DSLB2 = StImg.Buff[Pos+6];
                DSLB3 = StImg.Buff[Pos+9];
                DSLB4 = StImg.Buff[Pos+12];
                DSLB5 = StImg.Buff[Pos+15];
                DSLB6 = StImg.Buff[Pos+18];
                DSLB7 = StImg.Buff[Pos+21];
                for(Dot=0;Dot<8;Dot++) {
                            DisBuff[BuffPos] = DSLC00;
                            BuffPos +=306;
                } /* end of for(Dot) */
                Bpos++;
                BuffPos = Bpos;
        } /* end of for(i) */
}

/*=============================================================*/
/*                  Image RolProc Routine                      */
/*=============================================================*/
ImageRolProc(Tab)
int Tab;
{
    int i;
    int Pos;
    int Dot;
    int BuffPos=2142,Bpos=2142;
        Tab = (Tab>2)?(Tab-3)+7344:Tab;
        for(i = 0;i < 7344 ;i=i+24) {
                Pos   = i + Tab;
                DSLB0 = StImg.Buff[Pos];
                DSLB1 = StImg.Buff[Pos+3];
                DSLB2 = StImg.Buff[Pos+6];
                DSLB3 = StImg.Buff[Pos+9];
                DSLB4 = StImg.Buff[Pos+12];
                DSLB5 = StImg.Buff[Pos+15];
                DSLB6 = StImg.Buff[Pos+18];
                DSLB7 = StImg.Buff[Pos+21];
                for(Dot=0;Dot<8;Dot++) {
                            DisBuff[BuffPos] = DSLC00;
                            BuffPos -=306;
                } /* end of for(Dot) */
                Bpos++;
                BuffPos = Bpos;
        } /* end of for(i) */
}



/*=============================================================*/
/*                    SendBuff Routine                         */
/*=============================================================*/

char SendBuff(FontLine,LFLen,LFCt)
u_char FontLine;
u_int LFLen;
u_int *LFCt;
{
    union REG_UNION Reg0;
    u_int j,Ct=0;
    while((*LFCt) < FontLine) {
            SendFIFO(STX);
            SendFIFO(0);
            SendFIFO(5);
            if((*LFCt) == (FontLine-1)) {
                        Reg0.Two = LFLen;
                        SendFIFO(Reg0.Order.Hi);
                        SendFIFO(Reg0.Order.Low);
            }
            else {
                        SendFIFO(0);
                        SendFIFO(1);
            }
            for(j=0;j<306;j++) {
                        SendFIFO(DisBuff[Ct*306+j]);
            } /* end of for(j) */
            SendFIFO(ETX);
            if(Ct == 7) {
                        (*LFCt)++;
                        return 0;
            }
            Ct++;
            (*LFCt)++;
    } /* end of while */
    return -1;
}

/*=============================================================*/
/*                     SendSlave Routine                       */
/*=============================================================*/
SendSlave(Value)
u_char Value;
{
    union REG_UNION Reg0;
    SendFIFO(STX);
    SendFIFO(0);
    switch(Value) {
            case LPI_CMD :  SendFIFO(LPI_CMD);
                            Reg0.Two = LFInfo.DotLenOfLine;
                            SendFIFO(Reg0.Order.Hi);
                            SendFIFO(Reg0.Order.Low);
                            break;
            case PL_CMD  :  SendFIFO(PL_CMD);
                            Reg0.Two = PageLen;
                            SendFIFO(Reg0.Order.Hi);
                            SendFIFO(Reg0.Order.Low);
                            break;
            case LF_CMD  :  SendFIFO(LF_CMD);
                            Reg0.Two = (LFInfo.DotLenOfLine * LFInfo.Sum + AdjLPIErr(LFInfo.Sum));
                            SendFIFO(Reg0.Order.Hi);
                            SendFIFO(Reg0.Order.Low);
                            break;
            case FF_CMD  :  SendFIFO(FF_CMD);
                            SendFIFO(0);
                            SendFIFO(1);
                            break;
    }
}

/*=============================================================*/
/*                      ClrStImg Routine                       */
/*=============================================================*/
/* unsigned long *Target; */

ClrStImg(BuffLine)
u_char BuffLine;
{
    int i,Len;
    Len = (BuffLine/8) * 2448;
    for(i=0;i<Len;i++) {
                StImg.Buff[i] = 0;
    }
/* int i,Len;
    Target = &StImg.Buff[0];
    Len = (BuffLine/8) * (2448/4);
    asm(" MOVEA.L _Target,A0 ");
    asm(" MOVEQ.L #0,D0 ");
    for(i=0;i<Len;i++){
        asm(" MOVE.L  D0,(A0) ");
        asm(" ADDA.L #4,A0 ");
    }
*/

}

/*=============================================================*/
/*                      ToStImg Routine                        */
/*=============================================================*/

ToStImg(ChImg)
struct CH_IMG *ChImg;
{
    if((StImg.Pos + (ChImg->Col)) > (PAPER_DOT_WIDTH - Margin.Right)) {
            return OVER_RANGE;
    }
    if(StImg.Part == 0) {
            if(FontInfo.VTUp == SET) {
                        CopyToStImg(ST_IMG_PART0_BASE,CH_IMG_PART0_BASE,ChImg->Body);
                        StImg.HaveVTUp = SET;
            }
            else
            if(FontInfo.VTDn == SET) {
                        CopyToStImg(ST_IMG_PART0_BASE,CH_IMG_PART1_BASE,ChImg->Body);
            }
            else
            if(FontInfo.VTDouble == SET) {
                        CopyToStImg(ST_IMG_PART1_BASE,CH_IMG_PART0_BASE,ChImg->Body);
                        StImg.Pos -= ChImg->Col;
                        CopyToStImg(ST_IMG_PART0_BASE,CH_IMG_PART1_BASE,ChImg->Body);
                        StImg.HaveVT = SET;
            }
            else {
                        CopyToStImg(ST_IMG_PART0_BASE,CH_IMG_PART0_BASE,ChImg->Body);
            }
    }  /* End Of If(StImg.Part == 0) */
    else {  /* if(StImg.Part == 1) */
            if(FontInfo.VTUp == SET) {
                        CopyToStImg(ST_IMG_PART1_BASE,CH_IMG_PART0_BASE,ChImg->Body);
            }
            else
            if(FontInfo.VTDn == SET) {
                        CopyToStImg(ST_IMG_PART1_BASE,CH_IMG_PART1_BASE,ChImg->Body);
            }
            else
            if(FontInfo.VTDouble == SET) {
                        CopyToStImg(ST_IMG_PART1_BASE,CH_IMG_PART1_BASE,ChImg->Body);
            }
            else {
                        CopyToStImg(ST_IMG_PART1_BASE,CH_IMG_PART0_BASE,ChImg->Body);
            }
    }  /* End Of If(StImg.Part == 1) */
    EmptyImgBuff = RESET;
}

/*=============================================================*/
/*                   CopyToStImg Routine                       */
/*=============================================================*/

CopyToStImg(DestBase,SourBase,Body)
u_int DestBase;
u_int SourBase;
u_int Body;
{
    u_int Len;
    Len = SourBase + (Body*3);
    DestBase = DestBase + (StImg.Pos*3);
    for(;SourBase<Len;SourBase++,DestBase++) {
                    StImg.Buff[DestBase] = ChImg.Buff[SourBase];
                    ChImg.Buff[SourBase] = 0;
    }
    StImg.Pos += ChImg.Col;
}

/*=============================================================*/
/*                  LoadTB Routine (Font Loading)              */
/*=============================================================*/
LoadTB(FontAdr,ChInfo)
char *FontAdr;
struct CH_IMG *ChInfo;
{
    int i;
    int Len;
    Len = (ChInfo->Body)*3;
    for(i=0;i<Len;i++) {
                ChInfo->Buff[i] = *FontAdr;
                FontAdr++;
    }
}

/*=============================================================*/
/*                     HTDoubleTB Routine                      */
/*=============================================================*/
HTDoubleTB(FontAdr,ChInfo)
char *FontAdr;
struct CH_IMG *ChInfo;
{
int i,x=0;
     for(i=0; i<ChInfo->Body; i++){
         ChInfo->Buff[x]   = ChInfo->Buff[x+3] = *FontAdr;
         ChInfo->Buff[x+1] = ChInfo->Buff[x+4] = *(FontAdr+1);
         ChInfo->Buff[x+2] = ChInfo->Buff[x+5] = *(FontAdr+2);
         FontAdr += 3;
         x += 6;
     }
     ChInfo->Col  *= 2;
     ChInfo->Body *= 2;
}

/*=============================================================*/
/*                    VTDoubleTB Routine                       */
/*=============================================================*/
VTDoubleTB(FontAdr,ChInfo)
char *FontAdr;
struct CH_IMG *ChInfo;
{
int i,x=0;
     for(i=0; i<(ChInfo->Body);i++){
         ChInfo->Buff[x]     = VTFontTB[(*FontAdr)&0x0F];
         ChInfo->Buff[x+1]   = VTFontTB[((*FontAdr)&0xF0)>>4];
         ChInfo->Buff[x+2]   = VTFontTB[(*(FontAdr+1))&0x0F];
         ChInfo->Buff[x+144] = VTFontTB[((*(FontAdr+1))&0xF0)>>4];
         ChInfo->Buff[x+145] = VTFontTB[(*(FontAdr+2))&0x0F];
         ChInfo->Buff[x+146] = VTFontTB[((*(FontAdr+2))&0xF0)>>4];
         FontAdr += 3;
         x += 3;
     }
}

/*=============================================================*/
/*                  HTCondenseTB Routine                       */
/*=============================================================*/
HTCondenseTB(FontAdr,ChInfo)
char *FontAdr;
struct CH_IMG *ChInfo;
{
int x=0,i,Len;
     Len = ChInfo->Body/2;
     for(i=0; i<=Len; i++){
         ChInfo->Buff[x]   = *FontAdr     | *(FontAdr+3);
         ChInfo->Buff[x+1] = *(FontAdr+1) | *(FontAdr+4);
         ChInfo->Buff[x+2] = *(FontAdr+2) | *(FontAdr+5);
         FontAdr += 6;
         x += 3;
      }
     if(ChInfo->Body==13){
         ChInfo->Buff[x]   = *FontAdr;
         ChInfo->Buff[x+1] = *(FontAdr+1);
         ChInfo->Buff[x+2] = *(FontAdr+2);
         ChInfo->Body = 7;
         ChInfo->Col /= 2;
      }
     else{
         ChInfo->Body /= 2;
         ChInfo->Col  /= 2;
         }
}

/*=============================================================*/
/*                  HTVTDoubleTB Routine                       */
/*=============================================================*/
HTVTDoubleTB(FontAdr,ChInfo)
char *FontAdr;
struct CH_IMG *ChInfo;
{
int i,x=0;
     
     for(i=0; i<(ChInfo->Body); i++){
         ChInfo->Buff[x]    =ChInfo->Buff[x+3] = VTFontTB[(*FontAdr)&0x0F];
         ChInfo->Buff[x+1]  =ChInfo->Buff[x+4] = VTFontTB[((*FontAdr)&0xF0)>>4];
         ChInfo->Buff[x+2]  =ChInfo->Buff[x+5] = VTFontTB[(*(FontAdr+1))&0x0F];
         ChInfo->Buff[x+144]=ChInfo->Buff[x+147] = VTFontTB[((*(FontAdr+1))&0xF0)>>4];
         ChInfo->Buff[x+145]=ChInfo->Buff[x+148] = VTFontTB[(*(FontAdr+2))&0x0F];
         ChInfo->Buff[x+146]=ChInfo->Buff[x+149] = VTFontTB[((*(FontAdr+2))&0xF0)>>4];
         FontAdr += 3;
         x += 6;
      }

     ChInfo->Col  *= 2;
     ChInfo->Body *= 2;
}

/*=============================================================*/
/*                    ReverseMem Routine                       */
/*=============================================================*/
ReverseMem(ChImg)
struct CH_IMG *ChImg;
{
    int i,Len;
    Len = ChImg->Col * 3;
    if(FontInfo.VTDouble == SET) {
                    for(i=0;i<Len;i++) {
                                ChImg->Buff[i]     ^= 0xFF;
                                ChImg->Buff[144+i] ^= 0xFF;
                    }
    }
    else {
                    for(i=0;i<Len;i++) {
                                ChImg->Buff[i] ^= 0xFF;
                    }
    }
}

/*=============================================================*/
/*                    ShadowMem Routine                        */
/*=============================================================*/
ShadowMem(ChImg)
struct CH_IMG *ChImg;
{
    int i,Len,x=0;
    Len = ((ChImg->Col)/3);
    for(i=0;i<Len;i++) {
              ChImg->Buff[x]   |= 0x88;
              ChImg->Buff[x+1] |= 0x88;
              ChImg->Buff[x+2] |= 0x88;
              ChImg->Buff[x+12] |= 0x22;
              ChImg->Buff[x+13] |= 0x22;
              ChImg->Buff[x+14] |= 0x22;
              x+=24;
    }
}

/*=============================================================*/
/*                    UnderLineMem Routine                     */
/*=============================================================*/
UnderLineMem(ChImg)
struct CH_IMG *ChImg;
{
    int i,x;
    if(FontInfo.VTDouble == SET) {
              x = 146;
              for(i=0;i<ChImg->Col;i++) {
                    ChImg->Buff[x] |= 0x80;
                    x += 3;
              }
    }
    else {
              x = 2;
              for(i=0;i<ChImg->Col;i++) {
                    ChImg->Buff[x] |= 0x80;
                    x += 3;
              }
    }
}

/*=============================================================*/
/*                    BoldFaceMem Routine                      */
/*=============================================================*/
BoldFaceMem(ChImg)
struct CH_IMG *ChImg;
{
    int i,x=0;
    for(i=0;i<ChImg->Col;i++) {
              ChImg->Buff[x]   |= ChImg->Buff[x+3];
              ChImg->Buff[x+1] |= ChImg->Buff[x+4];
              ChImg->Buff[x+2] |= ChImg->Buff[x+5];
              x += 6;
    }
}

/*=============================================================*/
/*                      MakeKor Routine                        */
/*=============================================================*/
MakeKor(Data)
union INT_UNION Data;
{
u_int FontAdr;
u_int OffSet1;
u_int OffSet2;
    if((Data.Order.ChL == 0xA0) || (Data.Order.ChL == 0xFF)) {
                            Data.Tow = 0xB0A0;
    }
    if((0x0B0 <= Data.Order.ChH) && (Data.Order.ChH <= 0x0C8)) {
                if(HanFont == GODIC) {
                            OffSet1  = (Data.Order.ChH - 0xB0) * 11520;
                            OffSet2  = (Data.Order.ChH - 0xB0) * 2 * 24 * 3;
                            FontAdr = FONT_GKOR_ADR + (Data.Tow - KOR_START_CODE)*(KorFont[CpiMode].Body)*3 - OffSet1 - OffSet2;
                }
                else {
                            OffSet1  = (Data.Order.ChH - 0xB0) * 11520;
                            OffSet2  = (Data.Order.ChH - 0xB0) * 2 * 24 * 3;
                            FontAdr = FONT_MKOR_ADR + (Data.Tow - KOR_START_CODE)*(KorFont[CpiMode].Body)*3 - OffSet1 - OffSet2;
                }
                /*  FontPart = KOR_PART; */
    }
    else if((0xCA <= Data.Order.ChH) && (Data.Order.ChH <= 0xFD)) {
                OffSet1  = (Data.Order.ChH - 0xCA) * 11520;
                OffSet2  = (Data.Order.ChH - 0xCA) * 2 * 24 * 3;
                FontAdr = FONT_CHA_ADR + (Data.Tow - CHA_START_CODE)*(KorFont[CpiMode].Body)*3 - OffSet1 - OffSet2;
              /*  FontPart = CHA_PART; */
    }
    else if((0xA1 <= Data.Order.ChH) && (Data.Order.ChH <= 0xAC)) {
                OffSet1  = (Data.Order.ChH - 0xA1) * 11520;
                OffSet2  = (Data.Order.ChH - 0xA1) * 2 * 24 * 3;
                FontAdr = FONT_SP_ADR + (Data.Tow - SP_START_CODE)*(KorFont[CpiMode].Body)*3 - OffSet1 - OffSet2;
              /*  FontPart = SP_PART; */
    }
    else {
                return 0;
    }
    ChImg.Col  = KorFont[CpiMode].Col;
    ChImg.Body = KorFont[CpiMode].Body;
    ChImg.Rear = KorFont[CpiMode].Col - KorFont[CpiMode].Body;
/*    Skip11Flag = RESET; */
    switch(FontInfo.ScaleState = ScaleMode[GetDim3(FontInfo.HTCondense,FontInfo.VTDouble,FontInfo.HTDouble)])
    {
            case SM_NORMAL              : LoadTB(FontAdr,&ChImg);
                                          break;
            case SM_HTDOUBLE            : HTDoubleTB(FontAdr,&ChImg);
                                          break;
            case SM_VTDOUBLE            : VTDoubleTB(FontAdr,&ChImg);
                                          break;
            case SM_HTVTDOUBLE          : HTVTDoubleTB(FontAdr,&ChImg);
                                          /* HTScaleState = SET; */
                                          break;
            case SM_HTCONDENSE          : HTCondenseTB(FontAdr,&ChImg);
                                          /* Skip11Flag = SET; */
                                          break;
            case SM_VTDOUBLE_HTCONDENSE : /* VTDoubleTB(FontAdr,&ChImg); */
                                          /* HTCondenseMem(&ChImg,18); */
                                          /* Skip11Flag = SET; */
                                          break;
            default                     : break;
    }

/*    if(Skip11Flag == RESET) {
            if(CpiMode == 2) {
                        if((FontInfo.ScaleState == SM_HTDOUBLE) || (FontInfo.ScaleState == SM_HTVTDOUBLE) {
                                    HTCondenseTB(&ChImg,36);
                        }
                        else {
                                    HTCondenseMem(&ChImg,18);
                        }
            }
    }      */
    if(FontInfo.UnderLine == SET) {
            UnderLineMem(&ChImg);
    }
    if(FontInfo.BoldFace == SET) {
            BoldFaceMem(&ChImg);
    }
    if(FontInfo.Shadow == SET) {
            ShadowMem(&ChImg);
    }
    if(FontInfo.Reverse == SET) {
            ReverseMem(&ChImg);
    }
    if(ToStImg(&ChImg) == OVER_RANGE) {
            if(AutoWrap == SET) {
                    LFProc();
                    ToStImg(&ChImg);
            }
            else {
                    AutoWrapOver = SET;
            }
    }
}

/*=============================================================*/
/*                      MakeEng Routine                        */
/*=============================================================*/

MakeEng(Data)
union INT_UNION Data;
{
u_int FontAdr;
    if(Data.Order.ChH >= 0x80) {
         if(SemiMode == 1) {
                 FontAdr = FONT_SEMI1_ADR + (Data.Order.ChH - SEMI_START_CODE)*36;
                 ChImg.Col    = 18;
                 ChImg.Body   = 12;
                 ChImg.AdjMod = 0;
         } /* if */
         else {
                 FontAdr = FONT_SEMI2_ADR + (Data.Order.ChH - SEMI_START_CODE)*36;
                 ChImg.Col    = 18;
                 ChImg.Body   = 12;
                 ChImg.AdjMod = 0;
         } /* else */
    }
    else {
        switch(EngFont) {
                    case ENG1FONT : FontAdr = FONT_ENG1_ADR + (Data.Order.ChH - ENG_START_CODE)*(Eng1Font[CpiMode].Body)*3;
                                    ChImg.Col    = Eng1Font[CpiMode].Col;
                                    ChImg.Body   = Eng1Font[CpiMode].Body;
                                    ChImg.AdjMod = Eng1Font[CpiMode].AdjMod;
                                    break;
                    case ENG2FONT : FontAdr = FONT_ENG2_ADR + (Data.Order.ChH - ENG_START_CODE)*(Eng2Font[CpiMode].Body)*3;
                                    ChImg.Col    = Eng2Font[CpiMode].Col;
                                    ChImg.Body   = Eng2Font[CpiMode].Body;
                                    ChImg.AdjMod = Eng2Font[CpiMode].AdjMod;
                                    break;
                    case OCRFONT  : FontAdr = FONT_OCR_ADR + (Data.Order.ChH - ENG_START_CODE)*(OcrFont[CpiMode].Body)*3;
                                    ChImg.Col    = OcrFont[CpiMode].Col;
                                    ChImg.Body   = OcrFont[CpiMode].Body;
                                    ChImg.AdjMod = OcrFont[CpiMode].AdjMod;
                                    break;
                    default       : break;
        } /* End Of Switch */
    }
    switch(FontInfo.ScaleState = ScaleMode[GetDim3(FontInfo.HTCondense,FontInfo.VTDouble,FontInfo.HTDouble)])
    {
            case SM_NORMAL              : LoadTB(FontAdr,&ChImg);
                                          break;
            case SM_HTDOUBLE            : HTDoubleTB(FontAdr,&ChImg);
                                          break;
            case SM_VTDOUBLE            : VTDoubleTB(FontAdr,&ChImg);
                                          break;
            case SM_HTVTDOUBLE          : HTVTDoubleTB(FontAdr,&ChImg);
                                          /* HTScaleState = SET; */
                                          break;
            case SM_HTCONDENSE          : HTCondenseTB(FontAdr,&ChImg);
                                          break;
            case SM_VTDOUBLE_HTCONDENSE : /* VTDoubleTB(FontAdr,&ChImg); */
                                          /* HTCondenseMem(&ChImg,18); */
                                          break;
            default                     : break;
    }
    if(FontInfo.UnderLine == SET) {
            UnderLineMem(&ChImg);
    }
    if(FontInfo.BoldFace == SET) {
            BoldFaceMem(&ChImg);
    }
    if(FontInfo.Shadow == SET) {
            ShadowMem(&ChImg);
    }
    if(FontInfo.Reverse == SET) {
            ReverseMem(&ChImg);
    }
    if(ToStImg(&ChImg) == OVER_RANGE) {
            if(AutoWrap == SET) {
                    LFProc();
                    ToStImg(&ChImg);
            }
            else {
                    AutoWrapOver = SET;
            }
    }
}

/*=============================================================*/
/*                      Emulation Routine                      */
/*=============================================================*/

Emulation(u_char (*GetData)(void))
{
    if(KorEngMode == ONLY_ENGLISH_MODE) {
                Data.Order.ChH = ((*GetData)());
                if(Data.Order.ChH < 0x20) {
                            CtrProc(Data.Order.ChH);
                            return;
                }
                else {
                            if(AutoWrapOver == SET) {
                                    return;
                            }
                            else {
                                    MakeEng(Data);
                                    return;
                            }
                }
    }
    else {
                Data.Order.ChH = ((*GetData)());
                if(Data.Order.ChH > 0x80) {
                            Data.Order.ChL = ((*GetData)());
                            if(AutoWrapOver == SET) {
                                    return;
                            }
                            else {
                                    MakeKor(Data);
                                    return;
                            }
                }
                else
                if(Data.Order.ChH < 0x20) {
                            CtrProc(Data.Order.ChH);
                            return;
                }
                else {
                            if(AutoWrapOver == SET) {
                                    return;
                            }
                            else {
                                    MakeEng(Data);
                                    return;
                            }
                }
    }
}

/*=============================================================*/
/*                      CtrProc Routine                        */
/*=============================================================*/
CtrProc(CtrData)
u_char CtrData;
{
    int i;
    u_char TempDotLen;
    switch(CtrData) {
                    case 0    : break;
                    case BEL  : break;
                    case HT   : StImg.Pos = TabValue[TabCt];
                                TabCt++;
                                break;
                    case LF   : if(AutoWrapOver==SET){
                                        for(i=0;i<288;i++) {
                                                ChImg.Buff[i] = 0;
                                        }
                                        AutoWrapOver = RESET;
                                }
                                LFProc();
                                break;
                    case VT   : break;
                    case FF   : if(AutoWrapOver==SET){
                                        for(i=0;i<288;i++) {
                                                ChImg.Buff[i] = 0;
                                        }
                                        AutoWrapOver = RESET;
                                }
                                if(BitImgMode == BITIMG_24) {
                                        TempDotLen = LFInfo.DotLenOfLine;
                                        LFInfo.DotLenOfLine = 24;
                                        LFProc();
                                        LFInfo.DotLenOfLine = TempDotLen;
                                } /* if */
                                else {
                                        if(EmptyImgBuff == SET){
                                              LFProc();
                                        }
                                }
                                SendSlave(FF_CMD);
                                TabCt = 0;
                                break;
                    case CR   : if(AutoWrapOver==SET){
                                        for(i=0;i<288;i++) {
                                                ChImg.Buff[i] = 0;
                                        }
                                        AutoWrapOver = RESET;
                                }
                                StImg.Pos = Margin.Left;
                                break;
                    case SO   : AutoClr.So = SET;
                                FontInfo.HTDouble = SET;
                                break;
                    case SI   : FontInfo.HTCondense = SET;
                                break;
                    case DC2  : FontInfo.HTCondense = RESET;
                                break;
                    case DC4  : AutoClr.So = RESET;
                                FontInfo.HTDouble = AutoClrDC[AutoClr2(AutoClr.So,AutoClr.W)];
                                break;
                    case CAN  : ClrStImg(DOUBLE_BUFF);
                                StImg.Pos = 0;
                                break;
                    case ESC  : ESCProc((u_char(*)(void))(GetHostBuff));
                                break;
                    default   : break;
    }
}

/*=============================================================*/
/*                    ESCProc Routine                          */
/*=============================================================*/
ESCProc(u_char (*GetData)(void))
{
    u_char ActValue;
    u_char ImgHigh;
    u_char ImgLow;
    u_int  Temp;
    int i;
    u_int NullCnt;
    u_int Column;
    u_int Cnt;
    switch((*GetData)()) {
                    case ESC_UL    : ActValue = ((*GetData)());
                                     if(ActValue == SET) {
                                            FontInfo.UnderLine = SET;
                                     }
                                     else {
                                            FontInfo.UnderLine = RESET;
                                     }
                                     break;
                    case ESC_0     : LFInfo.DotLenOfLine = 180/8; /* 1/8 inch */
                                     LFInfo.AdjMod = ((180 % 8)*100)/8;
                                     LFInfo.AdjRemain = 0;
                                     break;
                    case ESC_1     : LFInfo.DotLenOfLine = 18; /* 1/10 inch */
                                     LFInfo.AdjMod = 0;
                                     LFInfo.AdjRemain = 0;
                                     break;
                    case ESC_2     : LFInfo.DotLenOfLine = 3 * EscATemp; /* 180 * (n/60) */
                                     LFInfo.AdjMod = (((EscATemp*180)%60)*100)/60;
                                     LFInfo.AdjRemain = 0;
                                     break;
                    case ESC_3     : ActValue = ((*GetData)());
                                     LFInfo.DotLenOfLine = ActValue; /* (ActValue*180)/180 , n/180 inch */
                                     LFInfo.AdjMod = (((ActValue*180)%180)*100)/180;
                                     LFInfo.AdjRemain = 0;
                                     break;
                    case ESC_6     : SemiMode = 1;
                                     break;
                    case ESC_7     : SemiMode = 0;
                                     break;
                    case ESC_A     : EscATemp = ((*GetData)());
                                     break;
                    case ESC_C     : ActValue = ((*GetData)());
                                     PageLen  = ActValue * LFInfo.DotLenOfLine;
                                     break;
                    case ESC_D     : while((ActValue = ((*GetData)())) != 0) {
                                         if(i < 20) {
                                                TabValue[i] = ActValue;
                                                i++;
                                         }
                                     }
                                     for(;i<20;i++)TabValue[i] = Margin.Left;
                                     break;
                    case ESC_E     : FontInfo.BoldFace = SET;
                                     break;
                    case ESC_F     : FontInfo.BoldFace = RESET;
                                     break;
                    case ESC_G     : break;
                    case ESC_H     : break;
                    case ESC_J     : ActValue = ((*GetData)());
                                     Temp = LFInfo.DotLenOfLine;
                                     LFInfo.DotLenOfLine = ActValue;
                                     LFProc();
                                     LFInfo.DotLenOfLine = Temp;
                                     break;
                    case ESC_K     : /* No Function */
                                     break;
                    case ESC_L     : /* No Function */
                    case ESC_U     : break;
                    case ESC_W     : ActValue = ((*GetData)());
                                     if(ActValue == SET) {
                                            AutoClr.W = SET;
                                            FontInfo.HTDouble = SET;
                                     }
                                     else {
                                            AutoClr.W = RESET;
                                            FontInfo.HTDouble = AutoClrW[AutoClr2(AutoClr.So,AutoClr.W)];
                                     }
                                     break;
                    case ESC_c     : ActValue = ((*GetData)());
                                     LFInfo.DotLenOfLine = 180/ActValue; /* (ActValue*180)/180 , n/180 inch */
                                     LFInfo.AdjMod = ((180%ActValue)*100)/ActValue;
                                     LFInfo.AdjRemain = 0;
                                     break;
                    case ESC_d     : ActValue = ((*GetData)());
                                     if(ActValue == SET) {
                                            AutoWrap = SET;
                                     }
                                     else {
                                            AutoWrap = RESET;
                                     }
                                     break;
                    case ESC_h     : ActValue = ((*GetData)());
                                     if(ActValue == SET) {
                                            KorEngMode = KORENG_MODE;
                                     }
                                     else {
                                            KorEngMode = ONLY_ENGLISH_MODE;
                                     }
                                     break;
                    case ESC_i     : ActValue = ((*GetData)());
                                     if(ActValue == 1) {
                                            FontInfo.VTUp = SET;
                                     }
                                     else
                                     if(ActValue == 2) {
                                            FontInfo.VTDn = SET;
                                     }
                                     else {
                                            FontInfo.VTUp = RESET;
                                            FontInfo.VTDn = RESET;
                                     }
                                     break;
                    case ESC_n     : BitImgMode = BITIMG_24;
                                     ImgLow     = ((*GetData)());
                                     ImgHigh    = ((*GetData)());
                                     Column     = ImgLow + ImgHigh*256;
                                /*     if(Column > (2448-(StImg.Pos+Margin.Right))){
                                        NullCnt = Column -(2448-(StImg.Pos+Margin.Right));
                                        Cnt = (2448-(StImg.Pos+Margin.Right));
                                     }
                                     else
                                     {  NullCnt = 0;
                                        Cnt = Column * 3;
                                     } */
                                     Cnt = Column * 3;
                                     for(i=0;i<Cnt;i++) {
                                            StImg.Buff[i] = ((*GetData)());
                                     }
                                /*     for(i=0;i<NullCnt;i++)ImgLow=((*GetData)()); */
                                     break;
                    case ESC_q     : ActValue = ((*GetData)());
                                     switch(ActValue) {
                                                case 0: CpiMode = 0;
                                                        break;
                                                case 1: CpiMode = 1;
                                                        break;
                                                case 2: CpiMode = 2;
                                                        break;
                                     }
                                     if((FontInfo.HTCondense == 1) && (ActValue == 2)) {
                                                CpiMode = 6;
                                     }
                                     break;
                    case ESC_m     : ActValue = ((*GetData)());
                                     if(ActValue == SET) {
                                            HanFont = GODIC;
                                     }
                                     else {
                                            HanFont = MYUNGJO;
                                     }
                                     break;
                    case ESC_r     : ActValue = ((*GetData)());
                                     if(ActValue == SET) {
                                            FontInfo.Reverse = SET;
                                     }
                                     else {
                                            FontInfo.Reverse = RESET;
                                     }
                                     break;
                    case ESC_t     : break;
                    case ESC_u     : ActValue = ((*GetData)());
                                     LFInfo.DotLenOfLine = (ActValue*180)/120;
                                     LFInfo.AdjMod = (((ActValue*180)%120)*100)/120;
                                     LFInfo.AdjRemain = 0;
                                     break;
                    case ESC_w     : break;
                    case ESC_x     : ActValue = ((*GetData)());
                                     break;
                    case ESC_y     : ActValue = ((*GetData)());
                                     if(ActValue == SET) {
                                            FontInfo.VTDouble = SET;
                                     }
                                     else {
                                            FontInfo.VTDouble = RESET;
                                     }
                                     break;
                    case ESC_z     : ActValue = ((*GetData)());
                                     if(ActValue == SET) {
                                            FontInfo.Reverse = SET;
                                     }
                                     else {
                                            FontInfo.Reverse = RESET;
                                     }
                                     break;
                    case ESC_HEAD  : break;
                    case ESC_s     : break;
                    default        : break;
    }
}

/*=============================================================*/
/*                   AutoClrCtr Routine                        */
/*=============================================================*/
AutoClrCtr()
{
    AutoClr.So = RESET;
    FontInfo.HTDouble = AutoClrLF[AutoClr2(AutoClr.So,AutoClr.W)];
    FontInfo.VTDouble = RESET;
}


int TestPt=0;
int TestCt=0;
u_char Temp[]={
                 0xB0,0xA1,0xB0,0xA2,0x1B,0x57,0x01,0x1B,0x79,0x01,
                 0xB1,0xA1,0xB1,0xA2,0xB1,0xA3,0xB1,0xA4,0xB1,0xA4,
                 0x12,0x35,0x36};
/*                 0x1B,0x37,0x80,0x81,0x82,0x83,0x84,0x85,0x86,0x87,
                 0x88,0x89,0x90,0x91,0x92,0x93,0x94,0x95,0x96,0x97}; */

/*--------------------------------------------- Test function -*/
u_char Test(void)
{
    u_char Ch = 0;
    Ch = Temp[TestPt];
    TestPt++;
    if(TestPt==21){ TestPt=0;TestCt++;
           if(TestCt==2){ TestCt=0; return(0x0A); }
    }
    return (Ch);
}

u_char TLow=0xA0,THi=0xB0;
u_char TTog = 0;
u_char Test2(void)
{
    u_char Ch = 0;
    if(THi==0xB7){THi=0xB0;TLow=0xA0;}
    if(TTog==0)  Ch = THi;
    else         {Ch = TLow;TLow++;}
    if(TLow==0xFF) {TLow=0;THi++;}
    TTog ^= 1;
    return Ch;
}


/*=============================================================*/
/*                    RunSelfTest Routine                      */
/*=============================================================*/
/* RunSelfTest()
{
    SaveAtt();
    SetBaseAtt();
    SendToSlave(SELF_TEST_START,LF_CMD,24);
    while(SelfTestStart != SELF_TEST_STOP) {
                Emulation(SELF_TEST_MODE);
    }
    if(EmptyImgBuf == RESET) {
                LFProc();
    }
    LoadAtt();
    SendToSlave(SELF_TEST_STOP,LF_CMD,24);
}  */

/*=============================================================*/
/*                  InstallItem Routine                        */
/*=============================================================*/
InstallItem()
{
    u_char i;
    for(i=0;i<14;i++) {
        switch(i) {
                case EMUL       : switch(SetItem[i]) {
                                    case KS      : HexDumpMode = RESET;
                                                   break;
                                    case KSSM    : HexDumpMode = RESET;
                                                   break;
                                    case TG      : HexDumpMode = RESET;
                                                   break;
                                    case HEXDUMP : HexDumpMode = SET;
                                                   break;
                                    default      : break;
                                  }
                                  break;
                case CH_PITCH   : switch(SetItem[i]) {
                                    case CPI10_2_1 : CpiMode = 0;
                                                     break;
                                    case CPI12_2_1 : CpiMode = 1;
                                                     break;
                                    case CPI10_1_1 : CpiMode = 2;
                                                     break;
                                    case CPI13_2_1 : CpiMode = 3;
                                                     break;
                                    case CPI10_3_2 : CpiMode = 4;
                                                     break;
                                    case CPI15_2_1 : CpiMode = 5;
                                                     break;
                                    default        : break;
                                  }
                                  break;
                case LINE_SPACE : switch(SetItem[i]) {
                                    case LPI_3 : LFInfo.DotLenOfLine = 180/3;
                                                 LFInfo.AdjMod = ((180%3)*100)/3;
                                                 LFInfo.AdjRemain = 0;
                                                 SendSlave(LPI_CMD);
                                                 break;
                                    case LPI_4 : LFInfo.DotLenOfLine = 180/4;
                                                 LFInfo.AdjMod = ((180%4)*100)/4;
                                                 LFInfo.AdjRemain = 0;
                                                 SendSlave(LPI_CMD);
                                                 break;
                                    case LPI_6 : LFInfo.DotLenOfLine = 180/6;
                                                 LFInfo.AdjMod = ((180%6)*100)/6;
                                                 LFInfo.AdjRemain = 0;
                                                 SendSlave(LPI_CMD);
                                                 break;
                                    case LPI_8 : LFInfo.DotLenOfLine = 180/8;
                                                 LFInfo.AdjMod = ((180%8)*100)/8;
                                                 LFInfo.AdjRemain = 0;
                                                 SendSlave(LPI_CMD);
                                                 break;
                                    default    : break;
                                  }
                                  break;
                case PRT_MODE   : switch(SetItem[i]) {
                                    case NORMAL    : break;
                                    case COPY      : break;
                                    case HAN300LPM : break;
                                    case ENG410LPM : break;
                                    default        : break;
                                  }
                                  break;
                case AUTOWRAP   : switch(SetItem[i]) {
                                    case ON  : AutoWrap = SET;
                                               break;
                                    case OFF : AutoWrap = RESET;
                                               break;
                                    default  : break;
                                  }
                                  break;
                case HAN_STYLE  : switch(SetItem[i]) {
                                    case BYTE_2_WAN : break;
                                    case BYTE_2_JOH : break;
                                    case BYTE_3_JOH : break;
                                    case BYTE_N_JOH : break;
                                    default         : break;
                                  }
                                  break;
                case HAN_FON    : switch(SetItem[i]) {
                                    case MYUNGJO : HanFont = MYUNGJO;
                                                   break;
                                    case GODIC   : HanFont = GODIC;
                                                   break;
                                    default      : break;
                                  }
                                  break;
                case ENG_FON    : switch(SetItem[i]) {
                                    case PRO_ENG : EngFont = ENG1FONT;
                                                   break;
                                    case OCR_B   : EngFont = OCRFONT;
                                                   break;
                                    case OCR_B_1 : break;
                                    default      : break;
                                  }
                                  break;
                case PAGE_LEN   : switch(SetItem[i]) {
                                    case INCH7    : PageLen = 180*7;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    case INCH7_5  : PageLen = 180*7.5;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    case INCH8    : PageLen = 180*8;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    case INCH8_5  : PageLen = 180*8.5;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    case INCH9    : PageLen = 180*9;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    case INCH9_5  : PageLen = 180*9.5;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    case INCH11   : PageLen = 180*11;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    case INCH11_5 : PageLen = 180*11.5;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    case INCH12   : PageLen = 180*12;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    case INCH14   : PageLen = 180*14;
                                                    SendSlave(PL_CMD);
                                                    break;
                                    default       : break;
                                  }
                                  break;
                case B_RATE     : switch(SetItem[i]) {
                                    case BPS_300   : M_BRATE = 7;
                                                     break;
                                    case BPS_600   : M_BRATE = 6;
                                                     break;
                                    case BPS_1200  : M_BRATE = 5;
                                                     break;
                                    case BPS_2400  : M_BRATE = 4;
                                                     break;
                                    case BPS_4800  : M_BRATE = 3;
                                                     break;
                                    case BPS_9600  : M_BRATE = 2;
                                                     break;
                                    case BPS_19200 : M_BRATE = 1;
                                                     break;
                                    case BPS_38400 : M_BRATE = 0;
                                                     break;
                                    default        : break;
                                  }
                                  break;
                case PARITY     : switch(SetItem[i]) {
                                    case NON  : break;
                                    case ODD  : break;
                                    case EVEN : break;
                                    default   : break;
                                  }
                                  break;
                case DATA_LEN   : switch(SetItem[i]) {
                                    case BIT_8 : break;
                                    case BIT_7 : break;
                                    default    : break;
                                  }
                                  break;
                case STOP_BIT   : switch(SetItem[i]) {
                                    case STOP_1 : break;
                                    case STOP_2 : break;
                                    default     : break;
                                  }
                                  break;
                case PROTOCOL   : switch(SetItem[i]) {
                                    case XON_OFF : Protocol = XON_MODE;
                                                   ACIACR   = 0xD5;
                                               /*    while((ACIASR & 0x02) != 0);
                                                   ACIADR = XON; */
                                                   break;
                                    case DTR     : Protocol = DTR_MODE;
                                                   ACIACR   = 0x95;
                                                   break;
                                    default      : break;
                                  }
                                  break;
        }
    }
}

/*=============================================================*/
/*                Master Initialization Routine                */
/*=============================================================*/
Initialize()
{
    SIOInit();
    while(StartEvent != SET);
}

/*=============================================================*/
/*                      Main Routine                           */
/*=============================================================*/

main()
{
    int i;
    u_char NewItemFlag;
    u_char TempDotLen;
    INT_ENB;
    TempInit();
    Initialize();
    while(1) {
            INT_DIS;
            if(ItemEvent == SET) {
                    for(i=0;i<14;i++) {
                            SetItem[i] = CmdBuf[i];
                    }
/*                    SetItem[2] = 2;
                    SetItem[8] = 6;
                    SetItem[9] = 5;
                    SetItem[13] = 1; */
                    ItemEvent   = RESET;
                    NewItemFlag = SET;
            }
            INT_ENB;
            if(EmptyImgBuff == SET) {
                    if(NewItemFlag == SET) {
                            NewItemFlag = RESET;
                            InstallItem();
                    }
                    if(SelfTestEvent == SELF_TEST_START) {
                            if(EmptyImgBuff == RESET) {
                                    LFProc();
                            }
                            else {
                       /*             RunSelfTest(); */
                            }
                    }
            }
            if(CheckHostBuff() == EMPTY) {
                    if((TimeOut > TIME_OUT) && (EmptyImgBuff == RESET)) {
                            TimeOut = 0;
                            if(BitImgMode == BITIMG_24) {
                                    TempDotLen = LFInfo.DotLenOfLine;
                                    LFInfo.DotLenOfLine = 24;
                                    LFProc();
                                    LFInfo.DotLenOfLine = TempDotLen;
                            } /* if */
                            else {
                                    LFProc();
                            }
                    }
                    if(TimeOutMode == SET) {
                            TimeOut++;
                    }
                    TimeOut = 0;
                    continue;
            }
            if(HexDumpMode == SET) {
                   /*       HexDump(); */
                    Emulation((u_char(*)(void))(HexTest));
            }
            else {
                    Emulation((u_char(*)(void))(GetHostBuff));
            }
    }  /* while(1) */
}








TempInit()
{
    u_int i;
    BitImgMode = 0;
    StImg.Part = 0;
    FontInfo.VTUp = RESET;
    FontInfo.VTDn = RESET;
    StImg.HaveVTUp = RESET;
    StImg.HaveVT = RESET;
    StImg.Pos = 0;
    LFInfo.Sum = 0;
    LFInfo.DotLenOfLine = 30;
    Margin.Left = 0;
    Margin.Right = 0;
    LFInfo.AdjMod = 0;
    LFInfo.AdjRemain = 0;
    HanFont = MYUNGJO;
    EngFont = ENG1FONT;
    CpiMode = 0;
    FontInfo.HTCondense = 0;
    FontInfo.VTDouble = 0;
    FontInfo.HTDouble = 0;
    FontInfo.Reverse  = RESET;
    FontInfo.Shadow = RESET;
    FontInfo.UnderLine = RESET;
    FontInfo.BoldFace = RESET;
    KorEngMode = KORENG_MODE;
    AutoWrap = SET;
    AutoWrapOver = RESET;
    AutoClr.So = RESET;
    AutoClr.W = RESET;
    HostPortMod = SERIAL_PORT;
    HexDumpMode = RESET;
    M_BRATE = 2;
    Protocol = XON_MODE;
    EmptyImgBuff = SET;
    SemiMode = 1;
    TimeOutMode  = SET;
    TabCt = 0;
    ClrStImg(DOUBLE_BUFF);
    for(i=0;i<20;i++) {
            TabValue[i] = 0;
    }
    for(i=0;i<288;i++) {
            ChImg.Buff[i] = 0;
    }
/*    while(1) {
                Emulation((u_char(*)(void))(Test));
    }   */
}
/*--------------------------------------*/

u_char xxp= 0;
unsigned char Togg=0;
unsigned char HData;
u_char HexTest()
{
    u_char Data;
             if(Togg==0){
                while(GetSIOBuff(&Data) == -1);
             /*   if(Data==0x0A) return 0x0A; */
                HData = Data;
                Data = (Data >> 4) & 0x0F;
                if(Data>9) Data+=0x37;
                else       Data+=0x30;
             }
             else{
                Data = HData & 0x0F;
                if(Data>9) Data+=0x37;
                else       Data+=0x30;
            }
    Togg ^= 1;
    return Data;
}
