/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : clrstimg.c                     */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                      ClrStImg Routine                       */
/*=============================================================*/

ClrStImg(BuffLine)      /* String Image Buffer Clear Function */
unsigned char BuffLine;
{
	register int i, j, Len = 0;
   	unsigned char *temp;
   	Len = (BuffLine/8) * 2448;
   	memset((&StImg.Buff[i]),0,Len);
}
