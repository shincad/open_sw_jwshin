/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : saveatt.c                      */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                  Save Attribute Routine                     */
/*=============================================================*/
SaveAtt()
{
	TempCpiMode   = CpiMode;
   	TempDotLen    = LFInfo.DotLenOfLine;
   	TempSum       = LFInfo.Sum;
   	TempAdjMod    = LFInfo.AdjMod;
   	TempAdjRemain = LFInfo.AdjRemain;
   	TempAutoWrap  = AutoWrap;
   	TempPrtSpeed  = PrtSpeed;
}
