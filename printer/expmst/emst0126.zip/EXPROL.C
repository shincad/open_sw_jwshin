/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : rolproc.c                      */
/*                  Program Date : 1997. 2.                    */
/*                  Program Update : 1997.6.14                 */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"
#include <stdlib.h>

/*=============================================================*/
/*                      RolProc Routine                        */
/*=============================================================*/

ExpRolProc(Tab)
int Tab;
{
    int i;
    int BuffPos=0,Bpos=0,Pos=0;
    Tab   = (Tab>3)?(Tab-4)+9792:Tab;
    for(i = 0;i < 9792 ;i=i+32) {
        Pos = i +Tab;
        DSLB0 = StImg.ExpBuff[Pos];
        DSLB1 = StImg.ExpBuff[Pos+4];
        DSLB2 = StImg.ExpBuff[Pos+8];
        DSLB3 = StImg.ExpBuff[Pos+12];
        DSLB4 = StImg.ExpBuff[Pos+16];
        DSLB5 = StImg.ExpBuff[Pos+20];
        DSLB6 = StImg.ExpBuff[Pos+24];
        DSLB7 = StImg.ExpBuff[Pos+28];

        DisBuff[BuffPos] = DSLC00;
        BuffPos+=306;
        DisBuff[BuffPos] = DSLC00;
        BuffPos+=306;
        DisBuff[BuffPos] = DSLC00;
        BuffPos+=306;
        DisBuff[BuffPos] = DSLC00;
        BuffPos+=306;
        DisBuff[BuffPos] = DSLC00;
        BuffPos+=306;
        DisBuff[BuffPos] = DSLC00;
        BuffPos+=306;
        DisBuff[BuffPos] = DSLC00;
        BuffPos+=306;
        DisBuff[BuffPos] = DSLC00;
        BuffPos+=306;
        Bpos++;
        BuffPos = Bpos;
    }
}

