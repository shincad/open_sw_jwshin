/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : setatt.c                       */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                  Set Base Attribute Routine                 */
/*=============================================================*/
SetBaseAtt()
{
	CpiMode = 0;
   	LFInfo.DotLenOfLine = 30;
   	LFInfo.AdjMod = 0;
   	LFInfo.AdjRemain = 0;
   	AutoWrap = RESET;
   	PrtSpeed = NORMAL;
}
