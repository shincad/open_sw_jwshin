#include <stdio.h>
#include <stdlib.h>

unsigned char buff[50][576];

ChCondense()
{
	int HighCnt,i,x=0,y=0;
	for(HighCnt=0; HighCnt<50;HighCnt++) {
		for(i=0; i<12; i++){
			buff[HighCnt][y]   = buff[HighCnt][x]     | buff[HighCnt][x+3];
			buff[HighCnt][y+1] = buff[HighCnt][x+1]   | buff[HighCnt][x+4];
			buff[HighCnt][y+2] = buff[HighCnt][x+2]   | buff[HighCnt][x+5];
			x += 6;
			y += 3;
		}
		x = 0;
        y = 0;
	}
}


main()
{
	FILE *fp, *fp1;
	int i;
	if( ( fp = fopen( "f7.fon", "rb" ) ) == NULL ) {
		fprintf( stderr, "Can't open file( f7.fon ) \n" );
		exit( 1 );
	}
	for(i=0;i<50;i++) {
		fread(buff[i], sizeof(unsigned char)*72, 1, fp);
	}

	ChCondense();

	if( ( fp1 = fopen( "test.fon", "wb" ) ) == NULL ) {
		fprintf( stderr, "Can't write file( test.fon ) \n" );
		exit( 1 );
	}
	for(i=0;i<50;i++) {
		fwrite(buff[i], sizeof(unsigned char)*72, 1, fp1);
	}

	fclose( fp  );
	fclose( fp1 );

}







