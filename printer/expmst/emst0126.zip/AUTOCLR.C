/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : autoclr.c                      */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                   AutoClrCtr Routine                        */
/*=============================================================*/
AutoClrCtr()    /* Esc W,SO,Esc y Auto Clear Code */
{
	AutoClr.So = RESET;
  	FontInfo.HTDouble = AutoClrLF[AutoClr2(AutoClr.So,AutoClr.W)];
    FontInfo.VTDouble = RESET;
}
