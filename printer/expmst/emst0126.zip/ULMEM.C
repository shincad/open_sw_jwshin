/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : ulmem.c                        */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                    UnderLineMem Routine                     */
/*=============================================================*/
UnderLineMem(ChImg)      /* UnderLine Character */
struct CH_IMG *ChImg;
{
	int i,x;
    if(PrtSpeed == SP_410LPM) {
    	if(FontInfo.VTDouble == SET) {
        	if(FontInfo.HTDouble == SET) {
            	x = 2;
                for(i=0;i<ChImg->Col;i++) {
                	ChImg->Buff[x] |= 0x80;
                    x += 3;
                }
            }
            else {
            	x = 2;
                for(i=0;i<ChImg->Col;i++) {
                	ChImg->Buff[x] |= 0x80;
                    x += 3;
                }
            }
        }
        else {
        	x = 1;
            for(i=0;i<ChImg->Col;i++) {
            	ChImg->Buff[x] |= 0x08;
                x += 3;
            }
        }
    }
    else {
    	if(FontInfo.VTDouble == SET) {
        	if(FontInfo.HTDouble == SET) {
            	x = 218;
                for(i=0;i<ChImg->Col;i++) {
                	ChImg->Buff[x] |= 0x80;
                    x += 3;
                }
            }
            else {
            	x = 146;
                for(i=0;i<ChImg->Col;i++) {
                	ChImg->Buff[x] |= 0x80;
                    x += 3;
                }
            }
        }
        else {
        	x = 2;
            for(i=0;i<ChImg->Col;i++) {
            	ChImg->Buff[x] |= 0x80;
                x += 3;
            }
        }
    }
}
