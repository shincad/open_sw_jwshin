/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : conprn.i                       */
/*                  Program Date : 1997. 2.                    */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

u_char Test2(void);

/*=============================================================*/
/*                    ConfigPrint Routine                      */
/*=============================================================*/

ConfigPrint()
{
   SelfSlv(0);
   Emulation((u_char(*)(void))(Test2));

}

u_char *TempDsp[] = { "KD20B","Line Printer","Welcome"};
int Cnt1 = 0;
int Index = 0;

u_char Test2(void)
{
   u_char Ch = 0;
   u_char StrCout;

   while(Cnt1 != 3) {
        StrCout = strlen(*(TempDsp+Cnt1));
        for(;Index<StrCout;) {
                Ch = *(*(TempDsp+Cnt1)+Index);
                if( Index == StrCout - 1 ) {
                        Cnt1++;
                        Index = 0;
                        return(Ch);
                } else {
                        Index++;
                        return(Ch);
                }
        }
/*        Cnt1++;
        return(TempBuff); */
   }
   if(Cnt1 == 3) {
                return(0x0a);
   }
}
