/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : getsio.c                       */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                    From HostBuff[] to FIFO                  */
/*=============================================================*/

char GetSIOBuff(Ch)
unsigned char *Ch;
{
	if(HRp == HWp) {          /* Read Pointer == Write Pointer */
    	return -1;
    }
    *Ch = HostBuff[HRp++];    /* from HostBuff Data reading */
    if(HRp > MAX_HBUFF) {     /* Ring Buffer Structure */
        HRp = 0;
    }
    if(HProtect == SET) {
    	Gap = HWp - HRp;
        if(Gap >= 0) {
        	if(Gap < P_LIVE) {
            	HProtect = RESET;
                if(Protocol == DTR_MODE) {
                	 ACIACR = 0x95; /* DTR = L */
                }
                else {
                	while((ACIASR & 0x02) != 0);
                    ACIADR = XON;
                    ACIADR = XON;
                    ACIADR = XON;
                }
            }
        }
        else {
        	if(Gap < -N_LIVE) {
            	HProtect = RESET;
                if(Protocol == DTR_MODE) {
                	ACIACR = 0x95;
                }
                else {
                    while((ACIASR & 0x02) != 0);
                    ACIADR = XON;
                    ACIADR = XON;
                    ACIADR = XON;
                }
            }
        }
    }
    return 0;
}
