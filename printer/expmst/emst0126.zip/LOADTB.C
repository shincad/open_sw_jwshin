/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : loadtb.c                       */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                  LoadTB Routine (Font Loading)              */
/*=============================================================*/
LoadTB(FontAdr,ChInfo)    /* Font Loading */
char *FontAdr;
struct CH_IMG *ChInfo;
{
	int i = 0;
    int Len;
    Len = (ChInfo->Body)*3;
    memcpy((&(ChInfo->Buff[i])),FontAdr,Len);
}
