#include <stdio.h>
#include <stdlib.h>

main()
{
	FILE *fp;
	int i;

	if( ( fp = fopen( "text", "wt" ) ) == NULL ) {
		fprintf( stderr, "Can't open file( text ) \n" );
		exit( 1 );
	}

	for (i=0;i<306;i++) {
		fprintf( fp, "DisBuff[(Ct+1)*306+%d] = DisBuff[(Ct+1)*306+%d] | DisBuff[(Ct+2)*306+%d];\n",i,i,i);

	/*	fprintf( fp, "Temp1 = &StImg.Buff[Tab+%d];\n", i * 24 ) ;
		fprintf( fp, "DSLB0 = *Temp1;\n" );
		fprintf( fp, "DSLB1 = *(Temp1+3);\n" );
		fprintf( fp, "DSLB2 = *(Temp1+6);\n" );
		fprintf( fp, "DSLB3 = *(Temp1+9);\n" );
		fprintf( fp, "DSLB4 = *(Temp1+12);\n" );
		fprintf( fp, "DSLB5 = *(Temp1+15);\n" );
		fprintf( fp, "DSLB6 = *(Temp1+18);\n" );
		fprintf( fp, "DSLB7 = *(Temp1+21);\n\n" );
		fprintf( fp, "*Temp2 = DSLC00;\n" );
		fprintf( fp, "*(Temp2+306) = DSLC00;\n" );
		fprintf( fp, "*(Temp2+612) = DSLC00;\n" );
		fprintf( fp, "*(Temp2+918) = DSLC00;\n" );
		fprintf( fp, "*(Temp2+1224) = DSLC00;\n" );
		fprintf( fp, "*(Temp2+1530) = DSLC00;\n" );
		fprintf( fp, "*(Temp2+1836) = DSLC00;\n" );
		fprintf( fp, "*(Temp2+2142) = DSLC00;\n" );
		fprintf( fp, "Temp2 = DisBuff+%d;\n",i ); */
	}
	fclose( fp );
}


