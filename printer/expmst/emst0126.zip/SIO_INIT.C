/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : sio_init.c                     */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                    Serial Initialization                    */
/*=============================================================*/

SIOInit()
{
    INT_DIS;
    HRp = 0;
    HWp = 0;
    HProtect = RESET;           /* XON/XOFF */
    ACIACR   = 0x03;   /* Control Register CR1,CR0=1,1 : Mst Reset */
    ACIACR   = 0xD5;   /* Parity Bit=None,Data Bit=8,Stop Bit=1,RTS = L */
                       /* DTR = H */
                       /* Tx interrupt Disable, Rx interrupt Enable */
    INT_ENB;
}
