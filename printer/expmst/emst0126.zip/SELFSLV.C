/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : selfslv.c                      */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                  SelfTest to Slave Routine                  */
/*=============================================================*/
SelfSlv(Cmd)
unsigned char Cmd;
{
	union REG_UNION Reg0;
   	SendFIFO(STX);
   	SendFIFO(Cmd);
   	SendFIFO(0);
   	Reg0.Two = 1;
   	SendFIFO(Reg0.Order.Hi);
   	SendFIFO(Reg0.Order.Low);
}
