/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : m_main.c                       */
/*                  Program Date : 1997. 2.                    */
/*                  1St Upgrade  : 1997. 4.                    */
/*                  Speed Upgrade : 1997. 5.                   */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include <stdio.h>
#include "m_define.h"
#include "mext.h"
#include "m_var.mem"

/*--------------------- HexDump Variable ----------------------*/
unsigned char Togg=0;
unsigned char HData;


/*=============================================================*/
/*                      Main Routine                           */
/*=============================================================*/

main()
{
	int i;
    unsigned char NewItemFlag;
    unsigned char TempDotLen;   /* Dot Length Temporary Buffer */
    INT_ENB;                    /* Interrupt Enable            */
    TempInit();                 /* Variable Initialization     */
    SaveAtt();                  /* Attribute Saving            */
    Initialize();               /* Initialize                  */
    while(1) {
    	INT_DIS;
        if(ItemEvent == SET) {
        	for(i=0;i<16;i++) {
            	SetItem[i] = CmdBuf[i];
            }
            ItemEvent   = RESET;
            NewItemFlag = SET;
        }
        INT_ENB;
        if(EmptyImgBuff == SET) {
        	if(NewItemFlag == SET) {
            	NewItemFlag = RESET;
                InstallItem();
            }
        }
        while(CheckHostBuff() == EMPTY) {     /* Host Buffer Checking */
        	if((TimeOut > TIME_OUT) && (EmptyImgBuff == RESET)) {
            	TimeOut = 0;
                if(BitImgMode == BITIMG_24) {
                	TempDotLen = LFInfo.DotLenOfLine;
                    LFInfo.DotLenOfLine = 24;
                    LFProc();
                    LFInfo.DotLenOfLine = TempDotLen;
                }
                else {
                    if((HexDumpMode == SET) && (Togg == 1))
                    {
                        Emulation((u_char(*)(void))(HexTest));
                        LFProc();
                        Togg = 0;
                        HData = 0;
                    }
                    LFProc();
                }
            }
            else
            if((TimeOutMode == SET) && (EmptyImgBuff == RESET)) {
            	TimeOut++;       /* CR = LF */
            }
            else {
                TimeOut = 0;
            }
            if(ItemEvent == SET) {
            	for(i=0;i<16;i++) {
                	SetItem[i] = CmdBuf[i];
                }
                ItemEvent   = RESET;
                NewItemFlag = SET;
            }
            if(NewItemFlag == SET) {
            	NewItemFlag = RESET;
                InstallItem();
            }
            if(SelfTestEvent == SELF_TEST_START) {   /* Self Test */
            	if(EmptyImgBuff == RESET) {
                	LFProc();
                }
                else {
                    RunSelfTest();  /* Self Test Routine */
                }
            }
        }
        if(HexDumpMode == SET) {                /* HexDump */
        	Emulation((u_char(*)(void))(HexTest));
        }
        else {
            Emulation((u_char(*)(void))(GetHostBuff));
        }
    }  /* while(1) */
}

/*=============================================================*/
/*                Variable Initialization Routine              */
/*=============================================================*/

TempInit()
{
	unsigned int i;
    BitImgMode = 0;
    StImg.Part = 0;
    FontInfo.VTUp = RESET;
    FontInfo.VTDn = RESET;
    StImg.HaveVTUp = RESET;
    StImg.HaveVT = RESET;
    StImg.Pos = 0;
    LFInfo.Sum = 0;
    Margin.Left = 0;
    Margin.Right = 0;
    LFInfo.AdjMod = 0;
    LFInfo.AdjRemain = 0;
    HanFont = MYUNGJO;
    EngFont = ENG1FONT;
    CpiMode = 0;
    FontInfo.HTCondense = 0;
    FontInfo.VTDouble = 0;
    FontInfo.HTDouble = 0;
    FontInfo.Reverse  = RESET;
    FontInfo.Shadow = RESET;
    FontInfo.UnderLine = RESET;
    FontInfo.BoldFace = RESET;
    KorEngMode = KORENG_MODE;
    AutoWrap = SET;
    AutoWrapOver = RESET;
    AutoClr.So = RESET;
    AutoClr.W = RESET;
    HostPortMod = SERIAL_PORT;
    HexDumpMode = RESET;
    M_BRATE = 2;
    Protocol = XON_MODE;
    EmptyImgBuff = SET;
    SemiMode = 1;
    TimeOutMode  = SET;
    TabCt = 0;
    TabLoad = 0;
    TimeOut = 0;
    EscJFlag = 0;
    SelfTestEvent = 0;
    ConfigEvent = 0;
    M_ACK = 0;
    M_PORTCS = 1;
    VT410Flag = RESET;
    VT300Flag = RESET;
    EscATempFlag = RESET;
    EscJFlag = RESET;
    HanStyle = BYTE_2_JOH;
    BuffRemainFlagFF = RESET;
    SemiExp = RESET;
    VertExpandFlag = RESET;

    VTabIdent = 0;
    VTabLoad  = 0;
    ClrStImg(DOUBLE_BUFF);       /* String Image Buffer Clear */
    memset((&StImg.ExpBuff[i]),0,9792);
    for(i=0;i<20;i++) {
    	TabValue[i] = 0;
    }
    for(i=0;i<432;i++) {         /* Character Buffer Clear */
        ChImg.Buff[i] = 0;
    }
}

/*==============================================================*/
/*                      Hex Dump Routine                        */
/*==============================================================*/

unsigned char HexTest()
{
	unsigned char Data;
    if(Togg==0){
    	while((GetSIOBuff(&Data) == -1) && (GetPIOBuff(&Data) == -1));
        HData = Data;
        Data = (Data >> 4) & 0x0F;
        if(Data>9) {
        	Data+=0x37;
        }
        else {
            Data+=0x30;
        }
    }
    else{
        Data = HData & 0x0F;
        if(Data>9) {
            Data+=0x37;
        }
        else {
            Data+=0x30;
        }
    }
    if((StImg.Pos != 0) &&(Togg == 0)) {
    	StImg.Pos += 36;
    }
    Togg ^= 1;
    return Data;
}
