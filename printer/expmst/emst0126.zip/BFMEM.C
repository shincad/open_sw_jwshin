/*=============================================================*/
/*                  KD20B Controller Program                   */
/*                  Module Name : MASTER                       */
/*                  File Name : bfmem.c                        */
/*                  Program Date : 1997. 2.                    */
/*                  Kia Information Systems.                   */
/*                  Printer Development Team.                  */
/*                  Programmed by Shin Jung Wook               */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                    BoldFaceMem Routine                      */
/*=============================================================*/
BoldFaceMem(ChImg)         /* BoldFace Character */
struct CH_IMG *ChImg;
{
	int i,x=0;
   	if(FontInfo.VTDouble == SET) {       /* Vertical Double Extension */
   		if(FontInfo.HTDouble == SET) {   /* Horizontal Double Extension */
      		for(i=0;i<ChImg->Col;i++) {
         		ChImg->Buff[x]     |= ChImg->Buff[x+3];
            	ChImg->Buff[x+1]   |= ChImg->Buff[x+4];
            	ChImg->Buff[x+2]   |= ChImg->Buff[x+5];
            	ChImg->Buff[x+216] |= ChImg->Buff[x+219];
            	ChImg->Buff[x+217] |= ChImg->Buff[x+220];
            	ChImg->Buff[x+218] |= ChImg->Buff[x+221];
            	x += 6;
         	} /* for */
      	} /* if */
    	else {
			for(i=0;i<ChImg->Col;i++) {
        		ChImg->Buff[x]     |= ChImg->Buff[x+3];
         		ChImg->Buff[x+1]   |= ChImg->Buff[x+4];
         		ChImg->Buff[x+2]   |= ChImg->Buff[x+5];
         		ChImg->Buff[x+144] |= ChImg->Buff[x+147];
         		ChImg->Buff[x+145] |= ChImg->Buff[x+148];
         		ChImg->Buff[x+146] |= ChImg->Buff[x+149];
         		x += 6;
        	} /* for */
    	} /* else */
   	} /* if */
   	else {                      /* Normal Character */
   		for(i=0;i<ChImg->Col;i++) {
      		ChImg->Buff[x]   |= ChImg->Buff[x+3];
         	ChImg->Buff[x+1] |= ChImg->Buff[x+4];
         	ChImg->Buff[x+2] |= ChImg->Buff[x+5];
         	x += 6;
      	} /* for */
   	} /* else */
}
