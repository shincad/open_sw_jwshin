/*=============================================================*/
/*  KD Line Printer Controller Firmware V2.2                   */
/*  TITLE    : autoclr.c                                       */
/*  ABSTRACT : Esc W,SO,Esc y Auto Clear Routine               */
/*  AUTHOR(S): Jung-Wook Shin                                  */
/*  DATE     : 1999. 1.                                        */
/*  Copyright (c) 1996-1999  by  Jung-Wook Shin                */
/*  Printer Lab. Phoenix Information Technology                */
/*  All rights reserved.                                       */
/*=============================================================*/

/*=============================================================*/
/*                  Include Header File                        */
/*=============================================================*/
#include "m_define.h"
#include "mext.h"

/*=============================================================*/
/*                   AutoClrCtr Routine                        */
/*=============================================================*/
AutoClrCtr()    /* Esc W,SO,Esc y Auto Clear Code */
{
	AutoClr.So = RESET;
  	FontInfo.HTDouble = AutoClrLF[AutoClr2(AutoClr.So,AutoClr.W)];
    FontInfo.VTDouble = RESET;
}
